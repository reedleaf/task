#ifndef _MANAGER_H_
#define _MANAGER_H_

int count = 0;
double wage[100];

void wageInput();
void showWageInfo();
void hihgWage();
void lowWage();
void avgWage();
void percentage();
void swap(double *a,double *b);
void sortWage(char c);

#endif //_MANAGER_H_